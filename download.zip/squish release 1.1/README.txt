The pygame license agreement says that if I am to distribute
something that uses pygame I must say so. I am using the pygame
library in squish. It comes with the LGPL (that's a license).
I must also provide the full pygame library. That's the pygame
folder that should have come with this package. The LGPL can be
found in the pygame folder, it's not in a subfolder of pygame,
just the main folder. You can delete the pygame folder with all
it's contents if you want to. Squish will run perfectly fine
without it.
				-Movitovi 07-Aug-2022